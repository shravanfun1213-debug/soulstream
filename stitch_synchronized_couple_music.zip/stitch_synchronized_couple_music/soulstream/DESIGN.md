---
name: SoulStream
colors:
  surface: '#081425'
  surface-dim: '#081425'
  surface-bright: '#2f3a4c'
  surface-container-lowest: '#040e1f'
  surface-container-low: '#111c2d'
  surface-container: '#152031'
  surface-container-high: '#1f2a3c'
  surface-container-highest: '#2a3548'
  on-surface: '#d8e3fb'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#d8e3fb'
  inverse-on-surface: '#263143'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bec6e0'
  primary: '#bec6e0'
  on-primary: '#283044'
  primary-container: '#0f172a'
  on-primary-container: '#798098'
  inverse-primary: '#565e74'
  secondary: '#d2bfe8'
  on-secondary: '#382a4a'
  secondary-container: '#4f4062'
  on-secondary-container: '#c0aed6'
  tertiary: '#ffb2b9'
  on-tertiary: '#67001f'
  tertiary-container: '#38000d'
  on-tertiary-container: '#d65569'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#eddcff'
  secondary-fixed-dim: '#d2bfe8'
  on-secondary-fixed: '#221534'
  on-secondary-fixed-variant: '#4f4062'
  tertiary-fixed: '#ffdadc'
  tertiary-fixed-dim: '#ffb2b9'
  on-tertiary-fixed: '#400010'
  on-tertiary-fixed-variant: '#891933'
  background: '#081425'
  on-background: '#d8e3fb'
  surface-variant: '#2a3548'
typography:
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: DM Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: DM Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 120px
---

## Brand & Style
The design system is centered on intimacy, shared rhythm, and emotional connection. It targets couples who seek a private, digital sanctuary for their musical journeys. The aesthetic is a blend of **Modern Minimalism** and **Glassmorphism**, creating an immersive environment that feels like a cozy, dimly lit room.

The emotional response should be one of "shared presence"—even when physically apart. We achieve this through deep, receding backgrounds that provide a sense of infinite space, contrasted with tactile, frosted-glass interface elements that feel close and touchable. The interface remains quiet and premium, allowing album art and shared "now playing" states to take center stage.

## Colors
The palette is built on a "Midnight and Petal" concept. 

- **Primary (Deep Navy):** Used for the core background levels to create depth and a cinematic atmosphere.
- **Secondary (Soft Lavender):** Used for supporting text, icons, and subtle borders. It provides a calming, romantic contrast to the dark base.
- **Tertiary (Rose Pink):** Reserved for high-emotion actions—"hearting" a track, active sync indicators, and primary call-to-actions.
- **Surface Neutrals:** Deep slate tones used for container backgrounds and divider lines to maintain structure without breaking the dark immersion.

Gradient overlays should be used sparingly, transitioning from Primary to a slightly lighter Navy to simulate ambient lighting in the corners of the viewport.

## Typography
The typography pairing balances expressive personality with functional clarity. 

**Bricolage Grotesque** is used for headlines. Its unique, slightly quirky terminals and ink traps provide a "hand-crafted" feel that adds character and warmth to the digital experience. It should be set with tight tracking in large sizes to emphasize its rhythmic quality.

**DM Sans** handles all secondary and body information. It is a clean, geometric sans-serif that remains highly legible even when rendered over translucent glass backgrounds or vibrant album art. Use the "Medium" weight for labels to ensure they "pop" against dark backgrounds.

## Layout & Spacing
The layout follows a **fluid-to-fixed** model. On mobile, we utilize a 4-column grid with generous 20px side margins to create a "contained" feel. On desktop, the content is centered within a 12-column grid with a maximum width of 1200px to maintain intimacy on large displays.

Spacing is aggressive in its use of whitespace (the "lg" and "xl" units) to prevent the UI from feeling cluttered. Elements should feel like they are floating in the deep navy "aether." Group related items using "xs" and "sm" units, while using "lg" to separate major sections like "Currently Listening" from "Recent Memories."

## Elevation & Depth
Elevation is communicated through **Glassmorphism** rather than traditional shadows. 

1.  **Level 0 (Base):** Solid Primary color (#0F172A).
2.  **Level 1 (Floating Cards):** Semi-transparent Neutral (#1E293B at 60% opacity) with a 12px backdrop-blur. A 1px border using Secondary (#E9D5FF at 10% opacity) defines the edges.
3.  **Level 2 (Active States/Modals):** Increased blur (20px) and a subtle Rose Pink (#FB7185) outer glow (15% opacity, 20px spread) to simulate light emanating from the screen.

Shadows, when used for buttons, are soft and colored (tinted with the Primary color) rather than pure black, ensuring they feel like ambient occlusions in a soft-lit room.

## Shapes
The shape language is consistently **Rounded**. 

The 0.5rem (8px) base radius provides a modern, friendly feel without being overly juvenile. For larger components like album art containers and primary glass cards, the `rounded-xl` (24px) setting is preferred to create a soft, protective "cradle" for content. Buttons should always use `rounded-lg` or `rounded-xl` to emphasize touchability and comfort.

## Components

- **Buttons:** Primary buttons use a solid Rose Pink fill with white text for maximum impact. Secondary buttons are "Ghost Glass"—transparent with a Lavender border and backdrop-blur.
- **Glass Cards:** The signature component. These must have a `backdrop-filter: blur(12px)` and a subtle 1px inner stroke to catch the light.
- **Sync Indicator:** A specialized component—a pulsating Rose Pink ring around the user's avatar to show they are listening in real-time with their partner.
- **Lists:** Music tracks are separated by wide spacing rather than lines. The "active" track in a list should have a soft Lavender glow behind it.
- **Inputs:** Fields are dark, inset boxes with a subtle Navy-to-Slate gradient. On focus, the border transitions to a soft Rose Pink.
- **The "Together" Bar:** A persistent bottom navigation/player that uses the highest level of glassmorphism (max blur) to float above the content, symbolizing the constant connection between the couple.